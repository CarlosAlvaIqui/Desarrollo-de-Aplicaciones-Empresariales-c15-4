<?php namespace GestorImagenes\Events;

abstract class Event {

	//

}
