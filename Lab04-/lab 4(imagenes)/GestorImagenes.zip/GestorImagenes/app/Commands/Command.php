<?php namespace GestorImagenes\Commands;

abstract class Command {

	//

}
